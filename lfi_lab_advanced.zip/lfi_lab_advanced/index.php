<?php
$page = $_GET['page'] ?? 'home';

// Lỗi: không lọc ../ hoặc php://
$filepath = "pages/" . $page . ".php";

// Cho phép include cả file hệ thống hoặc file log nếu path traversal thành công
include($filepath);
?>